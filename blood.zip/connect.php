<?php
@$con = mysqli_connect("localhost","root","","blooddonate") OR die ("failed to connect to database :(");
date_default_timezone_set("Asia/Baghdad");
?>