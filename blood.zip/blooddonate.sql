-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 23 يونيو 2020 الساعة 06:52
-- إصدار الخادم: 10.1.28-MariaDB
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blooddonate`
--

-- --------------------------------------------------------

--
-- بنية الجدول `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` varchar(80) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- إرجاع أو استيراد بيانات الجدول `admin`
--

INSERT INTO `admin` (`id`, `email`, `password`) VALUES
(1, 'ammar1994@mail.ru', 'Radargun');

-- --------------------------------------------------------

--
-- بنية الجدول `chat_message`
--

CREATE TABLE `chat_message` (
  `chat_message_id` int(11) NOT NULL,
  `to_user_id` int(11) NOT NULL,
  `from_user_id` int(11) NOT NULL,
  `chat_message` mediumtext NOT NULL,
  `message_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(2) NOT NULL,
  `second_status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- إرجاع أو استيراد بيانات الجدول `chat_message`
--

INSERT INTO `chat_message` (`chat_message_id`, `to_user_id`, `from_user_id`, `chat_message`, `message_time`, `status`, `second_status`) VALUES
(1, 3, 1, 'hello hassan', '2020-05-30 12:58:09', 1, 0),
(2, 3, 1, 'how are you', '2020-05-30 12:58:40', 1, 0);

-- --------------------------------------------------------

--
-- بنية الجدول `client`
--

CREATE TABLE `client` (
  `id` int(11) NOT NULL,
  `fullName` varchar(80) NOT NULL,
  `email` varchar(80) NOT NULL,
  `password` varchar(10) NOT NULL,
  `brithDate` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `bloodGroup` varchar(4) NOT NULL,
  `mobileNo` varchar(15) NOT NULL,
  `country` varchar(40) NOT NULL,
  `city` varchar(40) NOT NULL,
  `user_image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- إرجاع أو استيراد بيانات الجدول `client`
--

INSERT INTO `client` (`id`, `fullName`, `email`, `password`, `brithDate`, `gender`, `bloodGroup`, `mobileNo`, `country`, `city`, `user_image`) VALUES
(1, 'ammar', 'ammar@mail.ru', 'Radargun', '1 / 1 / 1950', 'male', 'A-', '07809720519', 'Ø§Ù„Ø¹Ø±Ø§Ù‚', 'Ø§Ù„Ø­Ù„Ø©', '543437708.jpg'),
(2, 'Ø§ÙŠÙ‡Ø§Ø¨ Ù…Ø¹ÙŠÙ†', 'ehab@mail.ru', 'Radargun', '1 / 1 / 1950', 'male', 'AB+', '07809720518', 'Ø§Ù„Ø¹Ø±Ø§Ù‚', 'Ø§Ù„Ø­Ù„Ø©', '426922765.jpg'),
(3, 'Ø­Ø³Ù† Ø¹Ø§Ø¯Ù„', 'hassan@mail.ru', 'Radargun', '1 / 1 / 1950', 'male', 'B+', '07809720517', 'Ø§Ù„Ø¹Ø±Ø§Ù‚', 'Ø§Ù„Ø¯ÙŠÙˆØ§Ù†ÙŠØ©', '635798418.jpg'),
(4, 'Ø¶Ø±ØºØ§Ù… Ø­Ø§ØªÙ…', 'dergham@mail.ru', 'Radargun', '1 / 1 / 1950', 'male', 'A-', '07809720513', 'Ø§Ù„Ø¹Ø±Ø§Ù‚', 'Ø§Ù„Ø¯ÙŠÙˆØ§Ù†ÙŠØ©', '908734834.jpg'),
(5, 'Ù†ÙˆØ± Ø¹Ù„ÙŠ', 'noor@mail.ru', 'Radargun', '1 / 1 / 1950', 'female', 'B-', '07809720514', 'Ø§Ù„Ø¹Ø±Ø§Ù‚', 'Ø§Ù„Ø³Ù…Ø§ÙˆØ©', '716572530.jpg');

-- --------------------------------------------------------

--
-- بنية الجدول `client_active`
--

CREATE TABLE `client_active` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `email` varchar(80) NOT NULL,
  `login_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- إرجاع أو استيراد بيانات الجدول `client_active`
--

INSERT INTO `client_active` (`id`, `client_id`, `email`, `login_time`) VALUES
(8, 2, 'ehab@mail.ru', '2020-05-27 09:38:15'),
(9, 4, 'dergham@mail.ru', '2020-05-27 09:40:34'),
(11, 5, 'noor@mail.ru', '2020-05-27 10:52:04'),
(12, 3, 'hassan@mail.ru', '2020-05-28 07:01:55'),
(17, 1, 'ammar@mail.ru', '2020-06-23 04:52:04');

-- --------------------------------------------------------

--
-- بنية الجدول `donate`
--

CREATE TABLE `donate` (
  `id` int(11) NOT NULL,
  `textDonate` text NOT NULL,
  `sickAge` int(3) NOT NULL,
  `sickGblood` varchar(4) NOT NULL,
  `sickCountry` varchar(80) NOT NULL,
  `sickCity` varchar(80) NOT NULL,
  `sickPhone` varchar(15) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `donate_type` varchar(20) NOT NULL,
  `from_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- إرجاع أو استيراد بيانات الجدول `donate`
--

INSERT INTO `donate` (`id`, `textDonate`, `sickAge`, `sickGblood`, `sickCountry`, `sickCity`, `sickPhone`, `date`, `donate_type`, `from_id`) VALUES
(1, 'Ù…Ø³Ø§Ø¡ Ø§Ù„Ø®ÙŠØ± \nØ§Ù†ÙŠ Ù…Ø­ØªØ§Ø¬ Ø§Ù„Ù‰ Ø´Ø®Øµ ÙŠØªØ¨Ø±Ø¹ Ù„ÙŠ Ø¨Ø§Ù„Ø¯Ù… Ø§Ù„ØªÙØ§ØµÙŠÙ„ Ø¨Ø§Ù„Ø§Ø³ÙÙ„', 25, 'O+', 'Ø§Ù„Ø¹Ø±Ø§Ù‚', 'ÙƒØ±Ø¨Ù„Ø§Ø¡ Ø§Ù„Ù…Ù‚Ø¯Ø³Ø©', '07810075463', '2020-05-27 09:37:34', 'needdonate', 2),
(2, 'Ø§Ù„Ø³Ù„Ø§Ù… Ø¹Ù„ÙŠÙƒÙ… \nØ§Ø®ÙˆØ§Ù† Ø§Ù†ÙŠ Ù…Ø³ØªØ¹Ø¯ Ù„Ù„ØªØ¨Ø±Ø¹ Ø¨Ø§Ù„Ø¯Ù… Ø§Ù„ÙŠ Ù…Ø­ØªØ§Ø¬ Ø¯Ù… ÙŠÙƒØ¯Ø± ÙŠØªÙˆØ§ØµÙ„ ÙˆÙŠØ§ÙŠ', 30, 'A+', 'Ø§Ù„Ø¹Ø±Ø§Ù‚', 'Ø§Ù„Ù…ÙˆØµÙ„', '07810075423', '2020-05-27 09:40:02', 'readydonate', 4),
(3, 'Ù…Ø±Ø­Ø¨Ø§ Ø§Ù†ÙŠ Ø§Ø­ØªØ§Ø¬ Ø§Ø­Ø¯ ÙŠØªØ¨Ø±Ø¹ Ø¨Ø¯Ù…Ù‡ Ø§Ù„ÙŠ ÙØµÙŠÙ„Ø© Ø§Ù„Ø¯Ù… Ø§Ù„Ù…Ø·Ù„ÙˆØ¨Ø© O', 35, 'O+', 'Ø§Ù„Ø¹Ø±Ø§Ù‚', 'Ø§Ù„Ø§Ù†Ø¨Ø§Ø±', '07842153676', '2020-05-27 09:42:36', 'needdonate', 3),
(4, 'Ù…Ø±Ø­Ø¨Ø§\nØ§Ù†ÙŠ Ù…Ø³ØªØ¹Ø¯Ø© Ù„Ù„ØªØ¨Ø±Ø¹ Ø¨Ø¯Ù…ÙŠ\n Ø²Ù…Ø±Ø© Ø¯Ù…ÙŠ A-\nØ¹Ù…Ø±ÙŠ 30  Ø³Ù†Ø©\nØªÙØ§ØµÙŠÙ„ Ø§Ù„ØªÙˆØ§ØµÙ„ ÙÙŠ Ø§Ù„Ø§Ø³ÙÙ„', 30, 'A-', 'Ø§Ù„Ø¹Ø±Ø§Ù‚', 'Ø§Ù„Ù†Ø¬Ù', '07810054284', '2020-05-27 09:53:41', 'readydonate', 5);

-- --------------------------------------------------------

--
-- بنية الجدول `notification`
--

CREATE TABLE `notification` (
  `id` int(11) NOT NULL,
  `donate_id` int(11) NOT NULL,
  `from_id` int(11) NOT NULL,
  `to_id` int(11) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- إرجاع أو استيراد بيانات الجدول `notification`
--

INSERT INTO `notification` (`id`, `donate_id`, `from_id`, `to_id`, `status`) VALUES
(1, 1, 2, 1, 1),
(2, 1, 2, 2, 1),
(3, 1, 2, 3, 1),
(4, 1, 2, 4, 1),
(5, 2, 4, 1, 0),
(6, 2, 4, 2, 1),
(7, 2, 4, 3, 1),
(8, 2, 4, 4, 1),
(9, 3, 3, 1, 1),
(10, 3, 3, 2, 1),
(11, 3, 3, 3, 1),
(12, 3, 3, 4, 1),
(13, 4, 5, 1, 1),
(14, 4, 5, 2, 1),
(15, 4, 5, 3, 1),
(16, 4, 5, 4, 1),
(17, 4, 5, 5, 1);

-- --------------------------------------------------------

--
-- بنية الجدول `password_reset`
--

CREATE TABLE `password_reset` (
  `id_reset_pass` int(11) NOT NULL,
  `email` varchar(80) NOT NULL,
  `random_token` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chat_message`
--
ALTER TABLE `chat_message`
  ADD PRIMARY KEY (`chat_message_id`),
  ADD KEY `messages` (`from_user_id`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mobileNo` (`mobileNo`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `client_active`
--
ALTER TABLE `client_active`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FOREIGN1` (`client_id`);

--
-- Indexes for table `donate`
--
ALTER TABLE `donate`
  ADD PRIMARY KEY (`id`),
  ADD KEY `donating` (`from_id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`id`),
  ADD KEY `donate_id` (`donate_id`);

--
-- Indexes for table `password_reset`
--
ALTER TABLE `password_reset`
  ADD PRIMARY KEY (`id_reset_pass`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `chat_message`
--
ALTER TABLE `chat_message`
  MODIFY `chat_message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `client_active`
--
ALTER TABLE `client_active`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `donate`
--
ALTER TABLE `donate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `password_reset`
--
ALTER TABLE `password_reset`
  MODIFY `id_reset_pass` int(11) NOT NULL AUTO_INCREMENT;

--
-- قيود الجداول المحفوظة
--

--
-- القيود للجدول `chat_message`
--
ALTER TABLE `chat_message`
  ADD CONSTRAINT `messages` FOREIGN KEY (`from_user_id`) REFERENCES `client` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- القيود للجدول `client_active`
--
ALTER TABLE `client_active`
  ADD CONSTRAINT `client_active_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `client` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- القيود للجدول `donate`
--
ALTER TABLE `donate`
  ADD CONSTRAINT `donating` FOREIGN KEY (`from_id`) REFERENCES `client` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- القيود للجدول `notification`
--
ALTER TABLE `notification`
  ADD CONSTRAINT `notification_ibfk_1` FOREIGN KEY (`donate_id`) REFERENCES `donate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
